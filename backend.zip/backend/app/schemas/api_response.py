from typing import Generic, Optional, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class APIResponse(BaseModel, Generic[T]):

    success: bool

    code: Optional[str] = None

    message: str

    data: Optional[T] = None